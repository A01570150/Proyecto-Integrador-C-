#ifndef Datos_h
#define Datos_h

#include "Fecha.h"
#include "Vuelo.h"

class Datos{
	
	private:
		Fecha fecha;
		string LoS;
		Vuelo vuelo;
		
	public:
	
		Datos();
		Datos(Fecha fecha,string LoS,Vuelo vuelo);
		
  	Fecha getFecha();
	  string getLoS();
	  Vuelo getVuelo();
	
};



Datos::Datos(){
	
  fecha = Fecha();
	LoS = " ";
	vuelo = Vuelo();
}


Datos::Datos(Fecha fecha,string LoS,Vuelo vuelo){
	
	this->fecha = fecha;
	this->LoS = LoS;
	this->vuelo = vuelo;
}


Fecha Datos::getFecha(){

  return fecha;
}

string Datos::getLoS(){
  return LoS;
}

Vuelo Datos::getVuelo(){

  return vuelo;
}

#endif







