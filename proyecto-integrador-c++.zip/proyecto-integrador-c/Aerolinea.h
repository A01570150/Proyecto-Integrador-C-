#ifndef Aerolinea_h
#define Aerolinea_h
#include <string>
using namespace std;

class Aerolinea{
private:
	string aerolinea;
	int llegadas;
	int salidas;
public:
	Aerolinea();
	Aerolinea(string aerolinea);
	void setAerolinea(string aerolinea);
	void setLlegadas(int llegadas);
	void setSalidas(int salidas);
	string getAerolinea();
	int getLlegadas();
	int getSalidas();
	void getincLlegadas();
	void getincSalidas();
};

Aerolinea:: Aerolinea() {
	aerolinea = "";
	llegadas = 0;
	salidas = 0;
};
Aerolinea::Aerolinea(string aerolinea) {
	this->llegadas = 0;
  this->salidas =0;
  this->aerolinea = aerolinea;

};

void Aerolinea::setAerolinea(string aerolinea) {
	this->aerolinea = aerolinea;
};
void Aerolinea::setLlegadas(int llegadas) {
	this->llegadas = llegadas;
};
void Aerolinea::setSalidas(int salidas) {
	this->salidas = salidas;
}
string Aerolinea::getAerolinea() {
	return aerolinea;
};
int Aerolinea::getLlegadas() {
	return llegadas;
}
int Aerolinea::getSalidas() {
	return salidas;
};
void Aerolinea::getincLlegadas() {
	llegadas++;
};
void Aerolinea::getincSalidas() {
	salidas++;
};
#endif
