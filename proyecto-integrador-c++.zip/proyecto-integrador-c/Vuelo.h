#ifndef Vuelo_h
#define Vuelo_h


class Vuelo{
private:
    string avion;
    int pasajeros;
    int capacidad;
    string aerolinea; 
    string vuelo;
    string destino;
public:
    Vuelo();
    Vuelo(string vuelo, string aerolinea,string destino,string avion,int pasajeros, int capacidad);
    int getPasajeros();
    string getAvion();
    string getVuelo();
    int getCapacidad();
    string getDestino();
    string getAerolinea();
};
Vuelo::Vuelo(){
    avion=" ";
    destino=" ";
    vuelo=" ";
    aerolinea=" ";
    capacidad=0;
    pasajeros=0;
}
Vuelo::Vuelo(string vuelo, string aerolinea,string destino,string avion,int pasajeros, int capacidad){
    this->avion = avion;
    this->vuelo = vuelo;
    this->aerolinea = aerolinea;
    this->pasajeros = pasajeros;
    this->capacidad = capacidad;
    this->destino = destino;
}

string Vuelo::getAvion(){
    return avion;
}
string Vuelo::getVuelo(){
    return vuelo;
}
string Vuelo::getDestino(){
    return destino;
}
int Vuelo::getPasajeros(){
    return pasajeros;
}
int Vuelo::getCapacidad(){
    return capacidad;
}
string Vuelo::getAerolinea(){
    return aerolinea;
}
#endif
