//Andres Pinones
//A01570150
#include <iostream>
#include <string>
#include <fstream>
#include <vector>

using namespace std;

#include "Vuelo.h"
#include "Fecha.h"
#include "Datos.h"
#include "Aerolinea.h"

int BuscaAerolinea(vector<Aerolinea> &aerolineas, string aerolinea){
   for (int i=0; i<aerolineas.size();i++){
     
    if (aerolinea == aerolineas[i].getAerolinea()){
      

      return i;
    }

  }
  
    aerolineas.push_back(Aerolinea(aerolinea));
    return aerolineas.size()-1;
   
}
void InicializaHoras(int horas[24]){
  for(int i = 0;i<24;i++){

    horas[i]=0;
  }
}

int main(){
	
	ifstream archivo;
	
	vector<Datos> datos;
	
	string fecha_str,hora_str,vuelo,LoS,aerolinea,destino,avion;
	
	int capacidad,pasajeros;
	
  int horas[24];
	
	
	archivo.open("datosVuelos.txt");
	
	int reng = 0;
	
	while( archivo >> fecha_str >> hora_str >> vuelo >> LoS >> aerolinea >> destino >> avion >> pasajeros >> capacidad){
		reng++;

    
		//Creamos en una linea un objeto que dentro de ese mismo objeto tiene dos objetos.
		datos.push_back(Datos(Fecha( fecha_str , hora_str ),LoS,Vuelo(vuelo,aerolinea,destino,avion,pasajeros,capacidad)));
	
	}

  cout<<"1. Hora de cada uno de los días que vienen en el archivo con mayor saturación."<<endl;

 InicializaHoras(horas);

 for(int j=0;j<reng;j++){
   if(j>0){
     if(datos[j].getFecha().getFechaStr()!=fecha_str){

      int mayor = 0;
      int hora = 0;

      for (int i=0;i<24;i++) {
        if (horas[i] > mayor) {
            hora = i;
            mayor = horas[i];
        }
      }
      cout<< "Para el día: "<< fecha_str <<" "<<"la hora más saturada es: "<<hora;
      cout<<" con "<<mayor <<" vuelos"<<endl;
      InicializaHoras(horas);
      
   
     }

   }
  fecha_str = datos[j].getFecha().getFechaStr();
  horas[datos[j].getFecha().getHora()]++;
 }
 int mayor = 0;
      int hora = 0;

      for (int i=0;i<24;i++) {
        if (horas[i] > mayor) {
            hora = i;
            mayor = horas[i];
        }
      }
      cout<< "Para el día: "<< fecha_str <<" "<<"la hora más saturada es: "<<hora;
      cout<<" con "<<mayor<<" vuelos"<<endl;
cout << endl;
 
cout<<"4. Cantidad de llegadas y salidas por aerolínea."<<endl;
vector<Aerolinea> aerolineas;
for(int j=0;j<reng;j++){
int pos = BuscaAerolinea(aerolineas,datos[j].getVuelo().getAerolinea());

if (datos[j].getLoS()=="S"){
  aerolineas[pos].getincSalidas();
}else{
  aerolineas[pos].getincLlegadas();
}
//For que arroja cant de llegadas y salidas por aerolinea.
}
for (int k=0;k<aerolineas.size();k++){
cout<<"Aerolinea: "<<aerolineas[k].getAerolinea()<<" Salidas: "<<aerolineas[k].getSalidas()<<" Llegadas: "<<aerolineas[k].getLlegadas()<<endl;
}
cout << endl;


cout<<"2. Cantidad de llegadas por hora promedio."<<endl;
cout<<"3. Cantidad de salidas por hora promedio."<<endl;
int llegadas_salidas[24][2]={};
for (int i=0;i<datos.size();i++){
  datos[i].getLoS();
  if (datos[i].getLoS()=="S"){
    llegadas_salidas[datos[i].getFecha().getHora()][0]++;
  }else{
    llegadas_salidas[datos[i].getFecha().getHora()][1]++;
  }
}
for (int i = 0; i < 24; i++){
    cout << "hora " << i << " - " << llegadas_salidas[i][0] << " salidas y " << llegadas_salidas[i][1] << " llegadas promedio" << endl;
}
cout << endl;

cout<<"5. Cantidad de pasajeros atendidos por día."<<endl;
cout<<"6. Porcentaje promedio de capacidad utilizada en los aviones, es decir la cantidad de pasajeros entre la capacidad de pasajeros de todos los vuelos cada día."<<endl;
float TCapacidad=datos[0].getVuelo().getCapacidad();
float Tpasajeros1=datos[0].getVuelo().getPasajeros();
float PCapacidad=0;
for(int i=0; i<datos.size();i++){
  if(datos[i].getFecha().getFechaStr()==datos[i+1].getFecha().getFechaStr()){
    TCapacidad+=datos[i+1].getVuelo().getCapacidad();
    Tpasajeros1+=datos[i+1].getVuelo().getPasajeros();
    PCapacidad=(Tpasajeros1/TCapacidad)*100;
  }else{
    cout<<"El dia "<<datos[i].getFecha().getFechaStr()<<": "<<endl;cout<<"Se atendieron a "<<Tpasajeros1<<" pasajeros"<<" ";
    cout<<"y la capacidad fue de "<<TCapacidad<<" pasajeros."<<endl;
    cout<<"El Porcentaje promedio de capacidad utilizada fue del "<<PCapacidad<<"%"<<endl; 
    TCapacidad=datos[i+1].getVuelo().getCapacidad();
    Tpasajeros1=datos[i+1].getVuelo().getPasajeros();
    
  }
}
	return 0;
}